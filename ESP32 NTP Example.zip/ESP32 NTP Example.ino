#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>

// Khai bao chan DHT22
#define DHTPIN 4
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);

// LCD I2C dia chi 0x27
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
  Serial.begin(115200);

  // Khoi tao DHT22
  dht.begin();

  // Khoi tao I2C ESP32
  Wire.begin(21, 22);

  // Khoi tao LCD
  lcd.init();
  lcd.backlight();

  lcd.setCursor(0, 0);
  lcd.print("ESP32 + DHT22");

  lcd.setCursor(0, 1);
  lcd.print("Initializing...");

  delay(2000);
  lcd.clear();
}

void loop() {
  // Doc nhiet do va do am
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();

  // Kiem tra loi cam bien
  if (isnan(temperature) || isnan(humidity)) {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Sensor Error!");
    Serial.println("Loi doc DHT22");
    delay(2000);
    return;
  }

  // Hien thi nhiet do
  lcd.setCursor(0, 0);
  lcd.print("Temp: ");
  lcd.print(temperature, 1);
  lcd.write(223);
  lcd.print("C  ");

  // Hien thi do am
  lcd.setCursor(0, 1);
  lcd.print("Humi: ");
  lcd.print(humidity, 1);
  lcd.print("%   ");

  // In du lieu Serial
  Serial.print("Nhiet do: ");
  Serial.print(temperature);
  Serial.print(" C | Do am: ");
  Serial.print(humidity);
  Serial.println(" %");

  delay(2000);
}